<?php
require 'db.php';

$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
function getCount($table) {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) AS count FROM $table");
    $row = $result->fetch_assoc();
    return $row['count'];
}
function getData($table) {
    global $conn;
    $result = $conn->query("SELECT * FROM $table ORDER BY created_at DESC");
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة الإدارة</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="admin_styles.css">
</head>
<body>
<header>
    <div class="container">
        <h1>لوحة الإدارة</h1><br>
        <nav>
            <ul>
                <li><a href="admin.php"> <i class="fas fa-home "></i> الرئيسية</a></li>
                <li><a href="admin.php?page=donations"><i class="fas fa-donate"></i> التبرعات</a></li>
                <li><a href="admin.php?page=contacts"  ><i class="fas fa-envelope"></i> الرسائل</a></li>
                <li><a href="admin.php?page=requests" ><i class="fas fa-car"></i> الطلبات</a></li>
                <li><a href="index.html" ><i class="fas fa-arrow-alt-circle-right"></i> العودة إلى الموقع</a></li>
            </ul>
        </nav>
    </div>
</header>

<section class="admin-content">
    <div class="container">
        <?php if ($page == 'dashboard') { ?>
            <h2>نظرة عامة</h2>
            <p>عدد الكتب المباعة: <?php echo getCount(table: ''); ?></p>
            <p>عدد الرسائل: <?php echo getCount('contact_messages'); ?></p>
            <p>عدد الطلبات: <?php echo getCount('request'); ?></p>
        <?php } elseif ($page == '') { ?>
            <h2>سجل التبرعات</h2>
            <p>إجمالي المبيعات: <?php echo getCount(''); ?></p>
            <table>
                <tr>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>المبلغ</th>
                    <th>طريقة الدفع</th>
                    <th>التاريخ</th>
                </tr>
                <?php foreach (getData(table: '') as $row) { ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['amount']; ?> ريال</td>
                        <td><?php echo $row['payment_method']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } elseif ($page == 'contacts') { ?>
            <h2>الرسائل المستلمة</h2>
            <p>إجمالي الرسائل: <?php echo getCount('contact_messages'); ?></p>
            <table>
                <tr>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>الهاتف</th>
                    <th>الرسالة</th>
                    <th>التاريخ</th>
                </tr>
                <?php foreach (getData('contact_messages') as $row) { ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td><?php echo $row['message']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } elseif ($page == 'requests') { ?>
            <h2>طلبات الخدمة</h2>
            <p>إجمالي الطلبات: <?php echo getCount('request'); ?></p>
            <table>
                <tr>
                    <th>الاسم</th>
                    <th>الهاتف</th>
                    <th>الكتاب </th>
                    <th>نوع الكتاب</th>
                    <th>اسم الكاتب</th>
                    <th>التفاصيل</th>
                    <th>التاريخ</th>
                </tr>
                <?php foreach (getData('request') as $row) { ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td><?php echo $row['location']; ?></td>
                        <td><?php echo $row['service_type']; ?></td>
                        <td><?php echo $row['branch']; ?></td>
                        <td><?php echo $row['details']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } ?>
    </div>
</section>
<footer>
    <div class="container">
    </div>
</footer>

</body>
</html>
